﻿var blazorHelpers = {}

blazorHelpers.Print = function () {
    window.print();
}